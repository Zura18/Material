package org.example.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;
import org.example.steps.FoodPageSteps;

public class FoodPage {
    public Locator restaurantButton, secondPageButton, gagraRestaurant, gagraDetails;

    public FoodPage(Page page) {
        this.restaurantButton = page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("რესტორანი"));
        this.secondPageButton = page.getByText("2", new Page.GetByTextOptions().setExact(true));
        this.gagraRestaurant = page.getByText("გაგრა", new Page.GetByTextOptions().setExact(false)).first();
        this.gagraDetails = page.locator("div.grid.grid-cols-12 > div.col-span-9");
    }
}
