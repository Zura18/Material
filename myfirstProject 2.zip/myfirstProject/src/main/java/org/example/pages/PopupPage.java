package org.example.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public class PopupPage {
    public Locator authorizationCloseButton, updateCloseButton, authorizationCloseButton1;

    public PopupPage(Page page) {
        this.authorizationCloseButton = page.frameLocator("dialog iframe")
                .nth(2)
                .locator("#content button[aria-label='Close']");

        this.authorizationCloseButton1 = page.frameLocator("dialog iframe")
                .nth(1)
                .locator("#content button[aria-label='Close']");

        this.updateCloseButton = page.frameLocator("dialog iframe[srcdoc]")
                .nth(0)
                .locator("#content button.close-button");
    }
}
