package org.example.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public class HomePage {
    public Locator foodCategory, languageSwitcher, languageContainer, searchContainer, searchButton, hotelButton;

    public HomePage(Page page) {
        this.foodCategory = page.locator("#category-15");
        this.languageSwitcher = page.getByAltText("language switch");
        this.languageContainer = page.locator("div.cursor-pointer:has(> img[alt='language switch'])");
        this.searchContainer = page.getByTestId("search-input-wrapper")
                .locator("input");
        this.searchButton = page.locator("button:has(img[alt='search'])");
        this.hotelButton = page.getByText("120", new Page.GetByTextOptions().setExact(false));
    }
}
