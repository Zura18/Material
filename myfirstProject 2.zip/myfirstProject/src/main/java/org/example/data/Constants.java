package org.example.data;

import org.example.steps.FoodPageSteps;

public class Constants {
    public static final String BASE_URL = "https://swoop.ge/";
    public static final String BASE_URL_ENG = "https://swoop.ge/en/";

    public static final String REST_URL = "https://swoop.ge/category/229/kveba/restorani/";
    public static final String GEO_LANG = "ქარ";
    public static final String ENG = "Eng",
    kakheti ="kakheti";
}
