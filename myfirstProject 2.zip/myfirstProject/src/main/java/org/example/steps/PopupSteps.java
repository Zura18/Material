package org.example.steps;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.options.WaitForSelectorState;
import org.example.pages.PopupPage;

public class PopupSteps extends PopupPage {
    private final Page page;

    public PopupSteps(Page page) {
        super(page);
        this.page = page;
    }

    public PopupSteps closeAuthorizePopup() {
        boolean closed = false;

        try {
            authorizationCloseButton.first()
                    .waitFor(new Locator.WaitForOptions()
                            .setState(WaitForSelectorState.VISIBLE)
                            .setTimeout(30_000));

            authorizationCloseButton.first().click();
            closed = true;

        } catch (PlaywrightException ignored) {
        }

        if (!closed) {
            try {
                authorizationCloseButton1.first()
                        .waitFor(new Locator.WaitForOptions()
                                .setState(WaitForSelectorState.VISIBLE)
                                .setTimeout(30_000));

                authorizationCloseButton1.first().click();

            } catch (PlaywrightException ignored) {
            }
        }
        return this;
    }

    public PopupSteps closeUpdatePopup() {
        try {
            updateCloseButton.first()
                    .waitFor(new Locator.WaitForOptions()
                            .setState(WaitForSelectorState.VISIBLE)
                            .setTimeout(30_000));

            updateCloseButton.first().click();

        } catch (PlaywrightException ignored) {
        }
        return this;
    }

}
