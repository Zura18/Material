package org.example.steps;

import com.microsoft.playwright.Page;
import org.example.pages.HomePage;
import org.example.data.Constants;
import org.example.pages.PopupPage;

import static org.example.data.Constants.*;

public class HomePageSteps extends HomePage {
    private final Page page;

    public HomePageSteps(Page page) {
        super(page);
        this.page = page;
    }
    public HomePageSteps clickFoodCategory(){
        foodCategory.click();
        return this;
    }
    public HomePageSteps switchToEnglish(){
        String currentLang = languageContainer.locator("p").innerText().trim();
        if (currentLang.equals(ENG)) {
            languageSwitcher.click();
        }
        page.waitForURL(BASE_URL_ENG);
        page.waitForTimeout(1000);
        return this;
    }
    public HomePageSteps switchToGeo(){
        String currentLang = languageContainer.locator("p").innerText().trim();
        if (currentLang.equals(GEO_LANG)) {
            languageSwitcher.click();
        }
        return this;
    }
    public HomePageSteps searchWord (String string) {
        searchContainer.fill(string);
        return this;
    }
    public HomePageSteps clickOnSearch(){
        searchButton.first().click();
       // page.waitForTimeout(7000);
        return this;
    }
    public HomePageSteps chooseHotel(){
        hotelButton.first().click();
        return this;
    }

}
