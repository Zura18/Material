package org.example.steps;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitForSelectorState;
import org.example.pages.FoodPage;

import static org.example.data.Constants.REST_URL;

public class FoodPageSteps extends FoodPage {
    private final Page page;

    public FoodPageSteps(Page page) {
        super(page);
        this.page = page;
    }
    public FoodPageSteps filterWithRestaurantAndWait(){
        restaurantButton.click();
        page.waitForURL(REST_URL);
        return this;
    }
    public FoodPageSteps navigateToSecondPage(){
        //secondPageButton.scrollIntoViewIfNeeded();
        secondPageButton.click();
        return this;
    }
    public FoodPageSteps chooseGagraRestaurant(){
        gagraRestaurant.scrollIntoViewIfNeeded();
        gagraRestaurant.click();
        return this;
    }

    public FoodPageSteps waitUntilGagraDetailsLoad(){
        gagraDetails.waitFor(
                new Locator.WaitForOptions()
                        .setState(WaitForSelectorState.VISIBLE)
                        .setTimeout(30_000)
        );
        return this;
    }

}
