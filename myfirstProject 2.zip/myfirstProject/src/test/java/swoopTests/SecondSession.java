package swoopTests;

import baseTests.BaseTest;
import org.example.steps.FoodPageSteps;
import org.example.steps.HomePageSteps;
import org.example.steps.PopupSteps;
import org.example.data.Constants;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.example.data.Constants.kakheti;

public class SecondSession extends BaseTest {
    private PopupSteps popupSteps;
    private HomePageSteps homePageSteps;
    private FoodPageSteps foodPageSteps;


    @BeforeClass
    public void setUpSteps() {
        popupSteps = new PopupSteps(getPage());
        homePageSteps = new HomePageSteps(getPage());
        foodPageSteps = new FoodPageSteps((getPage()));

        popupSteps.closeAuthorizePopup();
                //.closeUpdatePopup();
    }

    @Test
    public void openGagraRestaurant() {
        homePageSteps.clickFoodCategory();
        foodPageSteps.filterWithRestaurantAndWait()
                .navigateToSecondPage()
                .chooseGagraRestaurant();
    }

    @Test
    public void hotelSelection(){
        homePageSteps.switchToEnglish()
                .searchWord(kakheti)
                .clickOnSearch()
                .chooseHotel();
       // page.waitForTimeout(7000);
    }

}
