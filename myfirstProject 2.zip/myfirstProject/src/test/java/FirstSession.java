import com.microsoft.playwright.*;
import com.microsoft.playwright.options.AriaRole;
import org.testng.annotations.Test;

import java.util.List;

public class FirstSession {
    @Test
    public void openPage() {

        Playwright playwright = Playwright.create();

        Browser browser = playwright.chromium().launch(
                new BrowserType.LaunchOptions()
                        .setHeadless(false)
                        .setArgs(List.of("--start-maximized"))
        );

        BrowserContext context = browser.newContext(
                new Browser.NewContextOptions().setViewportSize(null)
        );

        Page page = context.newPage();
        page.navigate("https://swoop.ge/");

            page.frameLocator("dialog iframe").nth(1)
                .locator("#content button[aria-label='Close']")
                .click();

//        page.locator("#category-24")
//                .getByRole(AriaRole.LINK)
//                .click();
//        page.locator("#category-24 a").click();

        page.locator("#category-24").click();

//        page.getByRole(AriaRole.LINK,
//                        new Page.GetByRoleOptions().setName("დასვენება"))
//                .first()
//                .click();
//
//        page.locator("//a[.//p[text()='დასვენება']]").click();
//
//        page.locator("a:has(img[alt='დასვენება'])").click();

        page.waitForURL("https://swoop.ge/category/24/dasveneba/");

//        page.locator("[data-testid='search-input-wrapper'] input")
//                .fill("სასტუმრო");

        page.getByTestId("search-input-wrapper")
                .locator("input")
                .fill("დასვენება");

        //*[@id="__next"]//p[contains(text(), 'დასვენება')]  //  ცუდი პრაქტიკა
        page.waitForTimeout(5000);
    }
}
